create
    definer = root@localhost procedure GetCombinedData()
BEGIN
    SELECT t1.id as college_id, t1.full_name, t1.slug, t1.short_description, 
           COUNT(CASE WHEN t2.file_type = 'image' THEN 1 END) AS image_count,
           COUNT(CASE WHEN t2.file_type = 'doc' THEN 1 END) AS doc_count,
           COUNT(CASE WHEN t2.file_type = 'video' THEN 1 END) AS video_count
    FROM tbl_college t1
             JOIN tbl_uploaded_files t2 ON t1.id = t2.file_data
    GROUP BY t2.file_data;
END;

