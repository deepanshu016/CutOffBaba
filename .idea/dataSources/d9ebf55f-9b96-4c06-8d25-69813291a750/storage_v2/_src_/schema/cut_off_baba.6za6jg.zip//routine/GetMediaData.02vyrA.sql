create
    definer = root@localhost procedure GetMediaData(IN college_id int(20), IN file_types varchar(20))
BEGIN 
    -- Retrieve data for images
    SELECT * FROM tbl_uploaded_files WHERE file_type = file_types AND file_data = college_id;
    -- Retrieve data for videos
    SELECT * FROM tbl_uploaded_files WHERE file_type = file_types AND file_data = college_id;
    -- Retrieve data for documents
    SELECT * FROM tbl_uploaded_files WHERE file_type = file_types AND file_data = college_id;
END;

