create
    definer = root@localhost procedure DeleteByIDs(IN table_Name varchar(50), IN column_name varchar(50),
                                                   IN ids_list varchar(255))
BEGIN
    SET @query = CONCAT('DELETE FROM ',table_Name,' WHERE ', column_name, ' IN (', ids_list, ')');
    PREPARE statement FROM @query;
    EXECUTE statement;
    DEALLOCATE PREPARE statement;
END;

